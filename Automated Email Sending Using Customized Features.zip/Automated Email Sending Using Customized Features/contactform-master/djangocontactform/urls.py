import pygame

pygame.init()

win_width = 650
win_height = 400

win = pygame.display.set_mode((win_width, win_height))
pygame.display.set_caption("Bubble Sort")

x = 40
y = 40
width = 20
heights = [200, 50, 130, 90, 250, 61, 110, 88, 33, 80, 70, 159, 180, 20,30,40,55,16,10]

clock = pygame.time.Clock()
FPS = 60  

run = True
execute = False

start_time = pygame.time.get_ticks()
score = 0

def show(heights):
    for i, h in enumerate(heights):
        pygame.draw.rect(win, (255, 0, 0), (x + 30 * i, y, width, h))

def update_score():
    font = pygame.font.Font(None, 30)
    score_text = font.render("Score: " + str(score), True, (255, 255, 255))
    win.blit(score_text, (10, 10))

def update_timer():
    current_time = pygame.time.get_ticks() - start_time
    font = pygame.font.Font(None, 30)
    timer_text = font.render("Time: " + str(current_time // 1000) + "s", True, (255, 255, 255))
    win.blit(timer_text, (win_width - timer_text.get_width() - 10, 10))

while run:
    clock.tick(FPS)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_SPACE]:
        execute = True

    if not execute:
        win.fill((0, 0, 0))
        show(heights)
        update_score()
        update_timer()
        pygame.display.update()
    else:
        if len(heights) > 1:
            for i in range(len(heights) - 1):
                for j in range(len(heights) - i - 1):
                    if heights[j] > heights[j + 1]:
                        heights[j], heights[j + 1] = heights[j + 1], heights[j]
                        score += 1
                    win.fill((0, 0, 0))
                    show(heights)
                    update_score()
                    update_timer()
                    pygame.display.update()
                    pygame.time.delay(50)


pygame.quit()